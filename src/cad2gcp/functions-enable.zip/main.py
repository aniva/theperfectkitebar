from google.cloud import storage

def enable_bucket_public_access(request):
    """
    HTTP-triggered function to re-enable public access to the bucket.
    """
    bucket_name = "theperfectkitebar-cad-assets"

    client = storage.Client()
    bucket = client.bucket(bucket_name)

    print(f"Granting 'allUsers' object viewer role to bucket: {bucket_name}")
    policy = bucket.get_iam_policy(requested_policy_version=3)

    # Add the binding if it doesn't already exist
    found = False
    for binding in policy.bindings:
        if binding["role"] == "roles/storage.objectViewer":
            if "allUsers" not in binding["members"]:
                binding["members"].append("allUsers")
            found = True
            break
    if not found:
        policy.bindings.append({
            "role": "roles/storage.objectViewer",
            "members": ["allUsers"]
        })

    bucket.set_iam_policy(policy)
    return "Public access re-enabled.", 200
