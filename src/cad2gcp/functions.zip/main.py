from google.cloud import storage

def disable_bucket_public_access(event, context):
    """
    Cloud Function to disable public access to the bucket if called via Pub/Sub.
    """
    bucket_name = "theperfectkitebar-cad-assets"

    client = storage.Client()
    bucket = client.bucket(bucket_name)

    print(f"Revoking 'allUsers' access to bucket: {bucket_name}")
    policy = bucket.get_iam_policy(requested_policy_version=3)
    bindings = policy.bindings

    # Remove 'allUsers' from any role
    updated_bindings = []
    for binding in bindings:
        if "allUsers" in binding["members"]:
            binding["members"] = [m for m in binding["members"] if m != "allUsers"]
            if binding["members"]:  # keep the binding if others remain
                updated_bindings.append(binding)
        else:
            updated_bindings.append(binding)

    policy.bindings = updated_bindings
    bucket.set_iam_policy(policy)

    print("Public access removed successfully.")
